# LEGENDARY BLACKSMITH (Android)

## 빌드 방법
1. Android Studio를 설치합니다.
2. 이 프로젝트 폴더를 Android Studio에서 `Open`으로 엽니다.
3. Gradle Sync가 끝날 때까지 기다립니다.
4. 메뉴 `Build > Build Bundle(s) / APK(s) > Build APK(s)`를 선택합니다.
5. APK는 `app/build/outputs/apk/debug/app-debug.apk`에 생성됩니다.
6. 휴대폰으로 APK를 옮겨 설치합니다. 설치 시 출처를 알 수 없는 앱 설치 허용이 필요할 수 있습니다.

## 저장
게임 데이터는 Android WebView의 로컬 저장소(localStorage)에 저장됩니다. 앱을 종료하거나 재실행해도 저장됩니다. 앱 데이터를 삭제하거나 앱을 제거하면 저장 데이터가 사라질 수 있습니다.

## 요구사항
- Android Studio 최신 안정 버전 권장
- Android SDK Platform 35
- JDK 17 이상

## 사운드 업데이트
- `bgm.wav`: 오리지널 판타지 배경음악 (반복 재생)
- `hammer.wav`, `success.wav`, `fail.wav`, `break.wav`, `sell.wav`, `relic.wav`, `buy.wav`: 게임 효과음
- 게임 화면의 사운드 설정에서 배경음악과 효과음을 각각 켜고 끌 수 있습니다.
- 모바일 브라우저 정책상 최초 터치 이후 배경음악이 시작됩니다.
